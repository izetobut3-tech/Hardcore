package com.example.autopvp;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1842;
import net.minecraft.class_1844;
import net.minecraft.class_1847;
import net.minecraft.class_238;
import net.minecraft.class_2960;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3489;
import net.minecraft.class_3532;
import net.minecraft.class_3675;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9334;
import org.lwjgl.glfw.GLFW;

import java.util.Arrays;
import java.util.List;

public class AutoPvpClient implements ClientModInitializer {

    private static final double SALDIRI_MESAFESI = 3.5;
    private static final double NISAN_MESAFESI = 12.0;
    private static final double TARAMA_MESAFESI = 35.0;
    private static final float KACIS_CAN_ESIGI = 8.0f;
    private static final float TAM_CAN = 20.0f;
    private static final float DONUS_HIZI = 22.0f;
    private static final int BUFF_ARALIGI = 1800;
    public static boolean AKTIF = true;

    private static final List<String> KILIC_SIRASI = Arrays.asList(
            "minecraft:netherite_sword",
            "minecraft:diamond_sword",
            "minecraft:iron_sword",
            "minecraft:golden_sword",
            "minecraft:stone_sword",
            "minecraft:wooden_sword"
    );

    private boolean acilDurumMu = false;
    private int vurusBeklemesi = 0;
    private int zipEskimeSayaci = 0;
    private int saglikBeklemesi = 0;
    private int buffSayaci = 0;

    private static final class_304.class_11900 AUTOPVP_KATEGORI =
            class_304.class_11900.method_74698(class_2960.method_60655("autopvp", "main"));

    private static class_304 ACKAPA_TUSU;

    @Override
    public void onInitializeClient() {
        ACKAPA_TUSU = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.autopvp.togle",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_J,
                AUTOPVP_KATEGORI
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (ACKAPA_TUSU.method_1436()) {
                AKTIF = !AKTIF;
                if (AKTIF) {
                    buffSayaci = BUFF_ARALIGI;
                }
                if (client.field_1724 != null) {
                    client.field_1724.method_7353(
                            net.minecraft.class_2561.method_43470(AKTIF ? "AutoPvP: ACIK" : "AutoPvP: KAPALI"),
                            true
                    );
                }
            }
        });

        ClientTickEvents.END_CLIENT_TICK.register(this::herTick);
    }

    private void herTick(class_310 client) {
        if (!AKTIF) return;
        if (client.field_1724 == null || client.field_1687 == null || client.field_1761 == null) return;

        class_1657 ben = client.field_1724;
        if (saglikBeklemesi > 0) saglikBeklemesi--;

        buffSayaci++;
        if (buffSayaci >= BUFF_ARALIGI) {
            guclendirmeAt(client, ben);
            buffSayaci = 0;
        }

        if (ben.method_6032() <= KACIS_CAN_ESIGI) {
            acilDurumMu = true;
        } else if (ben.method_6032() >= TAM_CAN) {
            acilDurumMu = false;
        }

        if (acilDurumMu) {
            sifaIksiriAt(client, ben);
            return;
        }

        class_1657 dusman = enYakinDusman(client, ben);
        if (dusman == null) return;

        double mesafe = ben.method_5739(dusman);

        if (mesafe <= NISAN_MESAFESI) {
            enIyiKiliciKusan(ben);
            hedefeBak(ben, dusman, DONUS_HIZI);
        }

        if (mesafe <= SALDIRI_MESAFESI) {
            saldir(client, ben, dusman);
        }
    }

    private class_1657 enYakinDusman(class_310 client, class_1657 ben) {
        class_238 aramaAlani = ben.method_5829().method_1014(TARAMA_MESAFESI);
        List<class_1657> yakindakiler = client.field_1687.method_8390(
                class_1657.class, aramaAlani,
                p -> p != ben && p.method_5805() && !p.method_7325()
        );

        class_1657 enYakin = null;
        double enYakinMesafeKare = Double.MAX_VALUE;
        for (class_1657 p : yakindakiler) {
            double d = ben.method_5858(p);
            if (d < enYakinMesafeKare) {
                enYakinMesafeKare = d;
                enYakin = p;
            }
        }
        return enYakin;
    }

    private void hedefeBak(class_1657 ben, class_1657 hedef, float donusHizi) {
        double dx = hedef.method_23317() - ben.method_23317();
        double dy = hedef.method_23320() - ben.method_23320();
        double dz = hedef.method_23321() - ben.method_23321();
        double yatay = Math.sqrt(dx * dx + dz * dz);

        float hedefYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float hedefPitch = (float) -Math.toDegrees(Math.atan2(dy, yatay));

        float suankiYaw = ben.method_36454();
        float suankiPitch = ben.method_36455();

        float farkYaw = class_3532.method_15393(hedefYaw - suankiYaw);
        float farkPitch = hedefPitch - suankiPitch;

        float yeniYaw = suankiYaw + class_3532.method_15363(farkYaw, -donusHizi, donusHizi);
        float yeniPitch = suankiPitch + class_3532.method_15363(farkPitch, -donusHizi, donusHizi);
        yeniPitch = class_3532.method_15363(yeniPitch, -90.0f, 90.0f);

        ben.method_36456(yeniYaw);
        ben.method_36457(yeniPitch);
        ben.method_5636(yeniYaw);
        ben.method_5847(yeniYaw);
    }

    private void saldir(class_310 client, class_1657 ben, class_1657 dusman) {
        if (vurusBeklemesi > 0) {
            vurusBeklemesi--;
            return;
        }

        zipEskimeSayaci++;
        if (zipEskimeSayaci % 3 == 0 && ben.method_24828()) {
            ben.method_6043();
        }

        client.field_1761.method_2918(ben, dusman);
        ben.method_6104(class_1268.field_5808);

        vurusBeklemesi = 4;
    }

    private int potionSlotuBul(class_1657 ben, class_6880<class_1842> aranan) {
        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = ben.method_31548().method_5438(slot);
            if (stack.method_7909() != class_1802.field_8436) continue;
            class_1844 pcc = stack.method_58694(class_9334.field_49651);
            if (pcc == null) continue;
            if (pcc.comp_2378().isPresent() && pcc.comp_2378().get().equals(aranan)) {
                return slot;
            }
        }
        return -1;
    }

    private void ayaginaAt(class_310 client, class_1657 ben, int slot) {
        int oncekiSlot = ben.method_31548().method_67532();
        ben.method_31548().method_61496(slot);

        float eskiPitch = ben.method_36455();
        ben.method_36457(-90.0f);

        client.field_1761.method_2919(ben, class_1268.field_5808);

        ben.method_36457(eskiPitch);
        ben.method_31548().method_61496(oncekiSlot);
    }

    private void sifaIksiriAt(class_310 client, class_1657 ben) {
        if (saglikBeklemesi > 0) return;

        int slot = potionSlotuBul(ben, class_1847.field_8980);
        if (slot == -1) slot = potionSlotuBul(ben, class_1847.field_8963);
        if (slot == -1) return;

        ayaginaAt(client, ben, slot);
        saglikBeklemesi = 30;
    }

    private void guclendirmeAt(class_310 client, class_1657 ben) {
        int hizSlot = potionSlotuBul(ben, class_1847.field_8966);
        if (hizSlot != -1) {
            ayaginaAt(client, ben, hizSlot);
        }

        int kuvvetSlot = potionSlotuBul(ben, class_1847.field_8993);
        if (kuvvetSlot != -1) {
            ayaginaAt(client, ben, kuvvetSlot);
        }
    }

    private void enIyiKiliciKusan(class_1657 ben) {
        class_1799 suankiEl = ben.method_6047();
        if (suankiEl.method_31573(class_3489.field_42611)) return;

        int enIyiIndex = Integer.MAX_VALUE;
        int enIyiSlot = -1;

        for (int slot = 0; slot < 9; slot++) {
            class_1799 stack = ben.method_31548().method_5438(slot);
            String itemId = class_7923.field_41178.method_10221(stack.method_7909()).toString();
            int index = KILIC_SIRASI.indexOf(itemId);
            if (index != -1 && index < enIyiIndex) {
                enIyiIndex = index;
                enIyiSlot = slot;
            }
        }

        if (enIyiSlot != -1) {
            ben.method_31548().method_61496(enIyiSlot);
        }
    }
}
